.data:
    mensaje1: .asciiz "Ingrese un numero entero positivo: "
    resultado: .asciiz "La paridad del numero es (0 =Par, 1 = Impar): "
    newline: .asciiz "\n"

.text

main:

    li $v0, 5
    syscall
    move $a0, $v0
    
    jal paridad
   
    move $t0, $v0
    li $v0, 1
    move $a0, $t0
    syscall
    
    li $v0, 10
    syscall
    
            
paridad:
     addi $sp, $sp, -8
     sw $ra, 4($sp)
     sw $a0, 0($sp)
     
     beq $a0, $zero, caso_base
     
    
     addi $a0,$a0, -1
     jal paridad
     
     li $t1, 1
     sub $v0, $t1, $v0
     j fin
     
caso_base:
     li $v0,0
    
fin:
     lw $ra, 4($sp)
     lw $a0, 0($sp)
  k
     jr $ra                  
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
