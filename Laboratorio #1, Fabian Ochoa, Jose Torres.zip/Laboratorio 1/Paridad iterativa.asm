.data
	n: .word 1
.text	
	li $t0 , 0	#contador i
	li $v0 , 0	#Acumulador
	lw $s0 , n	#Numero del usuario	
#int main
	#Evaluamos la condicion 
	ble $s0, $zero, fin	#Si n <= 0 salta a fin 
	for:	
	    beq $t0, $s0 , fin	#Si i == n salta a fin 
	    #Como aun el i no es igual a n
	    li $t1 , 1	#Es el 1 de la operacion 
	    sub $v0 , $t1 , $v0		# $v0 = 1 - paridad(n-1)
	    addi $t0, $t0, 1		# i += 1	suma al contador 
	    j for
	    
	fin: 
	move $t0 , $v0 	#Resguardamos el resultado 
	#Llamadas al sistema 
	li $v0, 1 	#Mostrar un entero 
	move $a0, $t0 
	syscall
	
	li $v0, 10	#Esto es para finalizar el programa 
	syscall