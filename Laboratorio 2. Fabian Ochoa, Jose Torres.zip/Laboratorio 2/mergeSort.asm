.data
    vector: .word 15, 3, 9, 22, 45, 1, 8, 12, 19
    tmp:    .space 36          # 9 enteros * 4 bytes
    n:      .word 9
    space:  .asciiz " "
    msj:    .asciiz "Mergesort Compacto: "

.text
main:
    la   $a0, vector       # $a0 = dirección base original
    la   $a1, tmp          # $a1 = espacio temporal para fusiones
    li   $a2, 0            # $a2 = izq (0)
    lw   $a3, n
    addi $a3, $a3, -1      # $a3 = der (n - 1)
    jal  mergesort

    li   $v0, 4
    la   $a0, msj
    syscall
    li   $t0, 0
    la   $t2, vector
print:
    lw   $t1, n
    bge  $t0, $t1, salirj
    li   $v0, 1
    lw   $a0, 0($t2)
    syscall
    li   $v0, 4
    la   $a0, space
    syscall
    addi $t2, $t2, 4
    addi $t0, $t0, 1
    j    print
salir:
    li   $v0, 10
    syscall

mergesort:
    bge  $a2, $a3, fin_merge_rec # Condición base: izq >= der, salir
    j
    sw   $ra, 12($sp)
    sw   $a2, 8($sp)       # Guardar izq actual
    sw   $a3, 4($sp)       # Guardar der actual

    # Calcular medio: m = (izq + der) / 2
    add  $t0, $a2, $a3
    sra  $t0, $t0, 1       # $t0 = medio
    sw   $t0, 0($sp)       # Guardar medio en la pila

    # Llamada izquierda: mergesort(izq, medio)
    move $a3, $t0          # der = medio
    jal  mergesort

    # Llamada derecha: mergesort(medio + 1, der)
    lw   $t0, 0($sp)       # Recuperar medio
    addi $a2, $t0, 1       # izq = medio + 1
    lw   $a3, 4($sp)       # Recuperar der original
    jal  mergesort

    # Fusión: merge(izq, medio, der)
    lw   $a2, 8($sp)       # Restaurar izq original
    lw   $a3, 0($sp)       # Restaurar medio (pasa a ser $a3)
    lw   $t0, 4($sp)       # Recuperar der original
    
    addi $sp, $sp, -4
    sw   $t0, 0($sp)       # Pasamos 'der' mediante el tope de la pila
    jal  merge
    addi $sp, $sp, 4       # Limpiar el argumento 'der' de la pila

    lw   $a3, 4($sp)
    lw   $a2, 8($sp)
    lw   $ra, 12($sp)
    addi $sp, $sp, 16
fin_merge_rec:
    jr   $ra

merge:
    lw   $t0, 0($sp)       # $t0 = der
    move $t1, $a2          # $t1 = i (puntero izq = izq)
    addi $t2, $a3, 1       # $t2 = j (puntero der = medio + 1)
    move $t3, $a2          # $t3 = k (puntero tmp = izq)

m_loop:
    bgt  $t1, $a3, vaciar_j
    bgt  $t2, $t0, vaciar_i

    sll  $t4, $t1, 2
    add  $t4, $a0, $t4
    lw   $t5, 0($t4)       # V[i]

    sll  $t6, $t2, 2
    add  $t6, $a0, $t6
    lw   $t7, 0($t6)       # V[j]

    sll  $t8, $t3, 2
    add  $t8, $a1, $t8     # dirección tmp[k]

    bgt  $t5, $t7, c_der
    sw   $t5, 0($t8)
    addi $t1, $t1, 1
    j    m_next
c_der:
    sw   $t7, 0($t8)
    addi $t2, $t2, 1
m_next:
    addi $t3, $t3, 1
    j    m_loop
    
# T(n) = 2*t(n/2) + O(n)

vaciar_i:
    bgt  $t1, $a3, m_copy
    sll  $t4, $t1, 2
    add  $t4, $a0, $t4
    lw   $t5, 0($t4)
    sll  $t8, $t3, 2
    add  $t8, $a1, $t8
    sw   $t5, 0($t8)
    addi $t1, $t1, 1
    addi $t3, $t3, 1
    j    vaciar_i

vaciar_j:
    bgt  $t2, $t0, m_copy
    sll  $t6, $t2, 2
    add  $t6, $a0, $t6
    lw   $t7, 0($t6)
    sll  $t8, $t3, 2
    add  $t8, $a1, $t8
    sw   $t7, 0($t8)
    addi $t2, $t2, 1
    addi $t3, $t3, 1
    j    vaciar_j

m_copy:
    move $t1, $a2          # i = izq
copy_loop:
    bgt  $t1, $t0, m_end
    sll  $t4, $t1, 2
    add  $t5, $a1, $t4     # &tmp[i]
    add  $t6, $a0, $t4     # &vec[i]
    lw   $t7, 0($t5)
    sw   $t7, 0($t6)
    addi $t1, $t1, 1
    j    copy_loop
m_end:
    jr   $ra
