.data
array:  .word 9, 7, 5, 11, 12, 2, 14, 3, 10, 6  # Arreglo de ejemplo a ordenar
size:   .word 10                                # Tama�o del arreglo
space:  .asciiz " "
newline:.asciiz "\n"

.text
.globl main

main:
    # 1. Configurar argumentos para la primera llamada a quicksort
    la $a0, array       # $a0 = direcci�n base del arreglo
    li $a1, 0           # $a1 = �ndice 'low' = 0
    lw $t0, size
    subi $a2, $t0, 1    # $a2 = �ndice 'high' = size - 1

    # Llamar a la subrutina quicksort
    jal quicksort

    # 2. Imprimir el arreglo ordenado (Opcional, para verificaci�n)
    la $a0, array
    lw $a1, size
    jal print_array

    # 3. Finalizar ejecuci�n del programa
    li $v0, 10
    syscall


quicksort:
    # Caso base: if (low >= high) return
    bge $a1, $a2, end_quicksort

    # Pr�logo: Guardar contexto en la pila (Stack)
    addi $sp, $sp, -16
    sw $ra, 12($sp)      # Guardar Return Address
    sw $a0, 8($sp)       # Guardar direcci�n base
    sw $a1, 4($sp)       # Guardar 'low'
    sw $a2, 0($sp)       # Guardar 'high'

    # Llamar a partition(arr, low, high)
    jal partition
    move $s0, $v0        # $s0 = �ndice de pivote (pi)

    # Preparar recursividad 1: quicksort(arr, low, pi - 1)
    lw $a0, 8($sp)
    lw $a1, 4($sp)
    addi $a2, $s0, -1    # high = pi - 1
    jal quicksort

    # Preparar recursividad 2: quicksort(arr, pi + 1, high)
    lw $a0, 8($sp)
    addi $a1, $s0, 1     # low = pi + 1
    lw $a2, 0($sp)
    jal quicksort

    # Ep�logo: Restaurar contexto de la pila
    lw $ra, 12($sp)
    addi $sp, $sp, 16

end_quicksort:
    jr $ra

# ==========================================
# RUTINA: partition
# Retorna: $v0 = �ndice de partici�n
# ==========================================
partition:
    # Extraer el pivote: pivot = arr[high]
    sll $t0, $a2, 2      # $t0 = high * 4 (desplazamiento en bytes)
    add $t0, $a0, $t0    # $t0 = &arr[high]
    lw $t1, 0($t0)       # $t1 = pivote

    # Inicializar �ndices
    addi $t2, $a1, -1    # $t2 = i (low - 1)
    move $t3, $a1        # $t3 = j (low)

partition_loop:
    bge $t3, $a2, partition_end  # Si j >= high, salir del bucle

    # Obtener arr[j]
    sll $t4, $t3, 2      # $t4 = j * 4
    add $t4, $a0, $t4    # $t4 = &arr[j]
    lw $t5, 0($t4)       # $t5 = arr[j]

    # if (arr[j] < pivot)
    bge $t5, $t1, next_j

    # i++
    addi $t2, $t2, 1

    # Intercambiar arr[i] y arr[j] (swap)
    sll $t6, $t2, 2      # $t6 = i * 4
    add $t6, $a0, $t6    # $t6 = &arr[i]
    lw $t7, 0($t6)       # $t7 = arr[i]

    sw $t5, 0($t6)       # arr[i] = arr[j]
    sw $t7, 0($t4)       # arr[j] = temp

next_j:
    addi $t3, $t3, 1     # j++
    j partition_loop

partition_end:
    # Intercambiar arr[i + 1] y arr[high]
    addi $t2, $t2, 1     # i = i + 1
    sll $t6, $t2, 2      
    add $t6, $a0, $t6    # $t6 = &arr[i+1]
    lw $t7, 0($t6)       # $t7 = arr[i+1]

    sw $t1, 0($t6)       # arr[i+1] = pivote
    sw $t7, 0($t0)       # arr[high] = arr[i+1]

    # Retornar (i + 1)
    move $v0, $t2
    jr $ra

# ==========================================
# RUTINA AUXILIAR: print_array
# ==========================================
print_array:
    move $t0, $a0        # Direcci�n del arreglo
    move $t1, $a1        # Tama�o
    li $t2, 0            # �ndice = 0
print_loop:
    bge $t2, $t1, print_end
    lw $a0, 0($t0)
    li $v0, 1            # Syscall imprimir entero
    syscall
    la $a0, space
    li $v0, 4            # Syscall imprimir string (espacio)
    syscall
    addi $t0, $t0, 4     # Siguiente elemento
    addi $t2, $t2, 1     # Siguiente �ndice
    j print_loop
print_end:
    la $a0, newline
    li $v0, 4
    syscall
    jr $ra
