#------------------------------------------------------------
# Practica de Laboratorio 3 - Ejercicio 2
# Modulo de medicion de tension arterial (memory-mapped I/O)
# Entorno: MARS (MIPS32)
#------------------------------------------------------------

.data
    # Registros del dispositivo mapeados en memoria (simulados)
    TensionControl:  .word 0     # Escribir 1 -> inicia medicion
    TensionEstado:   .word 0     # 0 = midiendo, 1 = listo
    TensionSistol:   .word 0     # Resultado sistolica
    TensionDiastol:  .word 0     # Resultado diastolica

    msg_sistol:  .asciiz "Presion sistolica:  "
    msg_diastol: .asciiz "Presion diastolica: "
    newline:     .asciiz "\n"

.text
.globl main

#------------------------------------------------------------
# main: programa de prueba que invoca controlador_tension
#------------------------------------------------------------
main:
    # (En un sistema real, un proceso "hardware" externo iria
    #  actualizando TensionEstado/TensionSistol/TensionDiastol.
    #  Aqui, para poder probar en MARS, simulamos ese hardware
    #  con la subrutina simular_hardware, que se dispara desde
    #  dentro del controlador justo despues de iniciar la medicion.)

    jal controlador_tension      # $v0 = sistolica, $v1 = diastolica

    move $t0, $v0                # guardamos resultados
    move $t1, $v1

    li   $v0, 4
    la   $a0, msg_sistol
    syscall

    li   $v0, 1
    move $a0, $t0
    syscall

    li   $v0, 4
    la   $a0, newline
    syscall

    li   $v0, 4
    la   $a0, msg_diastol
    syscall

    li   $v0, 1
    move $a0, $t1
    syscall

    li   $v0, 4
    la   $a0, newline
    syscall

    li   $v0, 10                 # salir del programa
    syscall

#------------------------------------------------------------
# controlador_tension
# Descripcion:
#   1. Escribe 1 en TensionControl para iniciar la medicion.
#   2. Espera activamente (polling) mientras TensionEstado == 0.
#   3. Cuando TensionEstado == 1, lee TensionSistol y
#      TensionDiastol.
# Salida:
#   $v0 = valor sistolico
#   $v1 = valor diastolico
# Registros usados internamente: $t0, $t1 (no se preservan,
# es responsabilidad del llamador salvarlos si los necesita)
#------------------------------------------------------------
controlador_tension:
    # ---- 1. Iniciar la medicion ----
    li   $t0, 1
    la   $t1, TensionControl
    sw   $t0, 0($t1)              # TensionControl <- 1

    # --- SOLO PARA SIMULACION EN MARS ---
    # En hardware real este salto no existiria; el dispositivo
    # actualizaria TensionEstado por si solo con el tiempo.
    # IMPORTANTE: guardamos $ra en la pila antes de la llamada anidada,
    # porque "jal simular_hardware" sobrescribiria la direccion de
    # retorno hacia 'main', causando un ciclo infinito al final.
    addi $sp, $sp, -4
    sw   $ra, 0($sp)
    jal  simular_hardware
    lw   $ra, 0($sp)
    addi $sp, $sp, 4
    # --- FIN SIMULACION ---

espera_tension:
    la   $t1, TensionEstado
    lw   $t0, 0($t1)              # $t0 <- TensionEstado
    beq  $t0, 1, tension_lista    # si TensionEstado == 1, listo
    j    espera_tension           # espera activa (busy-wait)

tension_lista:
    la   $t1, TensionSistol
    lw   $v0, 0($t1)              # $v0 <- valor sistolico

    la   $t1, TensionDiastol
    lw   $v1, 0($t1)              # $v1 <- valor diastolico

    jr   $ra

#------------------------------------------------------------
# simular_hardware (SOLO para poder probar en MARS)
# Simula que el dispositivo termino de medir: escribe valores
# de ejemplo en TensionSistol/TensionDiastol y pone
# TensionEstado en 1.
#------------------------------------------------------------
simular_hardware:
    li   $t2, 120
    la   $t3, TensionSistol
    sw   $t2, 0($t3)

    li   $t2, 80
    la   $t3, TensionDiastol
    sw   $t2, 0($t3)

    li   $t2, 1
    la   $t3, TensionEstado
    sw   $t2, 0($t3)

    jr   $ra
