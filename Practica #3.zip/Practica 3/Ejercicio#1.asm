.data
    LuzControl: .word 0
    LuzEstado:  .word 0
    LuzDatos:   .word 0
  
    msg_ok:     .asciiz "Lectura exitosa. Nivel de luz: "
    msg_err:    .asciiz "Error: Fallo de hardware en el sensor"

.text
.globl main

main:
    # 1. Llamamos a la rutina para encender el sensor
    jal InicializarSensorLuz
    
    # --- SIMULACI�N DE HARDWARE ---
    
    la $t0, LuzEstado
    li $t1, 1           # Simulamos que el estado pas� a 1 (listo)[cite: 2]
    sw $t1, 0($t0)
    
    la $t0, LuzDatos
    li $t1, 850         # Simulamos una lectura de 850 (rango 0-1023)[cite: 2]
    sw $t1, 0($t0)
    # ------------------------------

    # 2. Leemos la luminosidad
    jal LeerLuminosidad
    
    # 3. Revisamos el c�digo de estado devuelto en $v1[cite: 2]
    li $t0, 1
    beq $v1, $t0, mostrar_error

    # Si $v1 es 0 (correcto), imprimimos el valor que vino en $v0[cite: 2]
    move $t2, $v0       
    
    la $a0, msg_ok
    li $v0, 4
    syscall
    
    move $a0, $t2
    li $v0, 1
    syscall
    
    j fin_programa

mostrar_error:
    la $a0, msg_err
    li $v0, 4
    syscall

fin_programa:
    li $v0, 10
    syscall


InicializarSensorLuz:
    # Escribir 0x1 en el registro de control para encenderlo[cite: 2]
    la $t0, LuzControl
    li $t1, 1               
    sw $t1, 0($t0)          

espera_activa:
    # Leer el registro de estado (Polling)
    la $t0, LuzEstado
    lw $t1, 0($t0)          
    
    # Mientras el estado sea 0 (no listo), el procesador se queda en este bucle[cite: 2]
    beqz $t1, espera_activa 
    
    # Si rompe el bucle, significa que el estado cambi� a 1 o -1. Retornamos.[cite: 2]
    jr $ra


LeerLuminosidad:
    la $t0, LuzEstado
    lw $t1, 0($t0)          

    # Revisamos si el hardware report� un error (-1)[cite: 2]
    li $t2, -1
    beq $t1, $t2, error_hardware 

    # Si no hubo error, el estado debe ser 1 (lectura disponible)[cite: 2]
    la $t0, LuzDatos
    lw $v0, 0($t0)          # Cargamos el dato real en $v0[cite: 2]
    li $v1, 0               # Ponemos $v1 en 0 indicando que todo sali� bien[cite: 2]
    jr $ra

error_hardware:
    li $v0, 0               # Limpiamos $v0 por seguridad
    li $v1, 1               # Ponemos $v1 en 1 para notificar el error a la rutina que nos llam�[cite: 2]
    jr $ra
