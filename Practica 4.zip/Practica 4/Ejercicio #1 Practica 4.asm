.data
    BUFFER_SIZE: .word 64            # Capacidad m�xima del buffer circular
    buffer:      .space 64           # Reserva de 64 bytes para el buffer
    
    msg_inicio:  .asciiz "\n--- Iniciando captura de 20s (May�sculas) ---\n"
    msg_fin:     .asciiz "\n[TIEMPO AGOTADO] Contenido del buffer circular:\n"
    msg_vacio:   .asciiz "(El buffer esta vacio)"
    newline:     .asciiz "\n"

.text
.globl main

main:
ciclo_principal:
    # 1. Imprimir mensaje de inicio de ciclo
    la $a0, msg_inicio
    li $v0, 4
    syscall

    # 2. Inicializar punteros y contadores del buffer circular
    li $s0, 0           # $s0 = head (�ndice de lectura)
    li $s1, 0           # $s1 = tail (�ndice de escritura)
    li $s2, 0           # $s2 = count (cantidad de caracteres guardados)
    lw $s3, BUFFER_SIZE # $s3 = l�mite del buffer (64 bytes)

    # 3. Obtener el tiempo de inicio en milisegundos (syscall 30)
    li $v0, 30
    syscall             # $a0 contiene los 32 bits bajos del tiempo actual
    move $s4, $a0       # $s4 = tiempo_inicio

bucle_20s:
    # a) Calcular tiempo transcurrido
    li $v0, 30
    syscall             # $a0 = tiempo_actual
    sub $t0, $a0, $s4   # $t0 = tiempo_actual - tiempo_inicio

    # Verificar si transcurrieron 20,000 ms (20 segundos)
    li $t1, 20000       
    bge $t0, $t1, fin_20s

    # b) Revisar si hay una tecla presionada en el receptor MMIO del teclado
    # 0xFFFF0000 -> Receiver Control Register
    # 0xFFFF0004 -> Receiver Data Register
    lui $t2, 0xffff
    lw $t3, 0($t2)      # Leer estado del teclado
    andi $t3, $t3, 1    # Bit 0 = 1 indica caracter disponible
    beqz $t3, bucle_20s # Si no hay entrada, contin�a el bucle de tiempo

    # c) Leer el car�cter de entrada
    lw $t4, 4($t2)      # Leer byte desde 0xFFFF0004

    # d) Filtrar solo may�sculas ('A' = 65 hasta 'Z' = 90)
    blt $t4, 65, bucle_20s   # Si ASCII < 'A', se descarta
    bgt $t4, 90, bucle_20s   # Si ASCII > 'Z', se descarta[cite: 4]

    # e) Guardar en el buffer circular si no est� lleno
    beq $s2, $s3, bucle_20s  # Si count == BUFFER_SIZE, ignora nuevas entradas

    la $t5, buffer
    add $t6, $t5, $s1        # Direcci�n exacta: buffer + tail
    sb $t4, 0($t6)           # Almacenar car�cter

    # Avanzar tail de forma circular: tail = (tail + 1) % BUFFER_SIZE[cite: 4]
    addi $s1, $s1, 1
    rem $s1, $s1, $s3

    # Incrementar cantidad de elementos guardados
    addi $s2, $s2, 1

    j bucle_20s

fin_20s:
    # 4. Imprimir todo el contenido acumulado en el buffer[cite: 4]
    la $a0, msg_fin
    li $v0, 4
    syscall

    # Si no se ingresaron letras may�sculas
    beqz $s2, buffer_vacio

imprimir_buffer:
    beqz $s2, vaciar_completado

    # Leer elemento actual apuntado por head
    la $t5, buffer
    add $t6, $t5, $s0
    lb $a0, 0($t6)

    # Imprimir car�cter individual (syscall 11)
    li $v0, 11
    syscall

    # Avanzar head de forma circular: head = (head + 1) % BUFFER_SIZE[cite: 4]
    addi $s0, $s0, 1
    rem $s0, $s0, $s3

    # Decrementar elementos restantes
    addi $s2, $s2, -1
    j imprimir_buffer

buffer_vacio:
    la $a0, msg_vacio
    li $v0, 4
    syscall

vaciar_completado:
    la $a0, newline
    li $v0, 4
    syscall

    # 5. Repetir el proceso indefinidamente[cite: 4]
    j ciclo_principal
